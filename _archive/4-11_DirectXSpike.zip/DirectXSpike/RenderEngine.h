#pragma once
//////////////////////////////////////////////////////////////////////////
// RenderEngine.h - 2011 Matthew Alford
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Includes
//////////////////////////////////////
#include "Terrain.h"
#include "Skybox.h"
#include "MeshManager.h"
#include "ShaderManager.h"
#include "SceneManager.h"
#include "LevelManager.h"

//////////////////////////////////////
// Forward Declarations
//////////////////////////////////////
class CHUD;

//////////////////////////////////////
// Type Definitions
//////////////////////////////////////

//////////////////////////////////////
// Class Definition
//////////////////////////////////////
class CRenderEngine
{
public:
	CRenderEngine(void);
	~CRenderEngine(void);

private:
	CMeshManager					m_meshMgr;
	CShaderManager					m_shaderMgr;
	CLevelManager					m_levelMgr;
	CSceneManager					m_sceneMgr;
	
	int								m_nBlurPasses;
	bool							m_bShowHUD;

	LPDIRECT3DDEVICE9				m_device;
	BaseModel*						m_renderQuadGeo;
	LPDIRECT3DTEXTURE9				m_texRenderTarget1;		/* texture for render target 1 */
	LPDIRECT3DTEXTURE9				m_texRenderTarget2;		/* texture for render target 2 */
	LPDIRECT3DTEXTURE9				m_texRenderTarget3;     /* texture for render target 3 */
	LPDIRECT3DSURFACE9				m_surRenderTarget1;		/* texture surface for render target 1 */
	LPDIRECT3DSURFACE9				m_surRenderTarget2;		/* texture surface for render target 2 */
//	LPDIRECT3DSURFACE9				m_surRenderTarget3;		/* texture surface for render target 3 */
	LPDIRECT3DSURFACE9				m_surBackBuffer;		/* back buffer for restoring after render target pass */
//	LPDIRECT3DTEXTURE9				m_texTest;				/* render target testing */
	CHUD*							m_pHud;					/* pointer to HUD manager */

	bool Setup(unsigned int viewportWidth, unsigned int viewportHeight);

public:
	void SetDevice(LPDIRECT3DDEVICE9 device, unsigned int viewportWidth, unsigned int viewportHeight);
	void RenderScene();
	void SetWireframeMode(bool enable);
	void SetPlayerObject(CPlayer* pPlayer);
	void Update(LPDIRECT3DDEVICE9 device, float elapsedMillis);
	
	inline CMeshManager &GetMeshManager() {return m_meshMgr;}
	inline void SetBlur(int blurs) {m_nBlurPasses = blurs;}
	inline void SetHUD(CHUD *hud) {m_pHud = hud;}
	inline void DrawDebugQuadTree(bool draw) {m_sceneMgr.DrawDebugQuadTree(draw);}
	inline D3DXVECTOR3 GetLightDirection(void) {return m_shaderMgr.GetLightDirection();}
	inline void SetDebugRotateLight(bool rotate) {m_shaderMgr.SetDebugRotateLight(rotate);}
	inline void SetShowHUD(bool show) {m_bShowHUD = show;}
	inline void ToggleClipMethod() {m_sceneMgr.SetNextClipStrategy();}
	inline LPDIRECT3DDEVICE9 GetDevice() {return m_device;}
	inline CSceneManager &GetSceneManager() {return m_sceneMgr;}
	inline CShaderManager &GetShaderManager() {return m_shaderMgr;}
	
	bool CreateRenderTarget(void);
};