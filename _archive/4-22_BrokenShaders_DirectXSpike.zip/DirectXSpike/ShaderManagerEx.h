#pragma once
#include "shadermanager.h"

class CShaderManagerEx :
	public CShaderManager
{
public:
	CShaderManagerEx(void);
	~CShaderManagerEx(void);

	virtual void Setup();

	void SetWorldTransformEx(D3DXMATRIX worldTransform);
	void SetViewProjectionEx(D3DXMATRIX viewProjTransform);
	int BeginEffect(); // returned num of passes
	void Pass(UINT pass);
	void SetTechnique(LPCSTR name);
	void FinishEffect();
	void FinishPass();

private:
	LPD3DXEFFECT	m_effect;
	D3DXHANDLE		m_hWorldTransform;
	//m_hViewTransform
	//	m_hProjectionTransform
	D3DXHANDLE		m_hViewProjection;
	//	m_hDirectionToLight
};
