#include "StdAfx.h"
#include "ShaderManagerEx.h"

CShaderManagerEx::CShaderManagerEx(void) : m_effect(NULL),
											m_hWorldTransform(0)
{
}

CShaderManagerEx::~CShaderManagerEx(void)
{
	COM_SAFERELEASE(m_effect);
}


void CShaderManagerEx::Setup(void)
{
	// call the base class
	CShaderManager::Setup();

	// create the effect (material)
	ID3DXBuffer*	errors = NULL;

	VERIFY_SUCCESS(D3DXCreateEffectFromFile( 
		m_device, 
		"Shaders//SkyDome.fx", 
		NULL, 
		NULL, 
		0/*no flags*/, 
		NULL, 
		&m_effect, 
		&errors ));

	if( errors )
	{
		::MessageBox(0, (char*)errors->GetBufferPointer(), 0, 0 );
		COM_SAFERELEASE( errors );
		return;
	}

	// set up the parameters
	
	//m_effect->GetParameterByName( m_hViewTransform, "viewTransform" );
	
	//m_effect->GetParameterByName( m_hProjectionTransform, "projectionTransform" );
	//m_effect->GetParameterByName( m_hDirectionToLight, "dirToLight" );
}

void CShaderManagerEx::SetWorldTransformEx(D3DXMATRIX worldTransform)
{
	D3DXHANDLE h=0;
	m_effect->GetParameterByName( h, "matWorld" );
	VERIFY_SUCCESS(m_effect->SetMatrix(h, &worldTransform));
}

void CShaderManagerEx::SetViewProjectionEx(D3DXMATRIX viewProjTransform)
{
	D3DXHANDLE h=0;
	m_effect->GetParameterByName( h, "matViewProjection" );
	VERIFY_SUCCESS(m_effect->SetMatrix(h, &viewProjTransform));
}

int CShaderManagerEx::BeginEffect()
{
	UINT numPasses;
	VERIFY_SUCCESS(m_effect->Begin(&numPasses, 0));

	return (int)numPasses;
}

void CShaderManagerEx::Pass(UINT pass)
{
	VERIFY_SUCCESS(m_effect->BeginPass(pass));
}

void CShaderManagerEx::SetTechnique(LPCSTR name)
{
	VERIFY_SUCCESS(m_effect->SetTechnique(m_effect->GetTechniqueByName(name)));
}

void CShaderManagerEx::FinishEffect()
{
	VERIFY_SUCCESS(m_effect->End());
}

void CShaderManagerEx::FinishPass()
{
	VERIFY_SUCCESS(m_effect->EndPass());
}