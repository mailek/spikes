#pragma once
//////////////////////////////////////////////////////////////////////////
// MeshManager.h - 2011 Matthew Alford
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Includes
//////////////////////////////////////
#include "BaseModel.h"

//////////////////////////////////////
// Forward Declarations
//////////////////////////////////////
class CTerrain;

//////////////////////////////////////
// Type Definitions
//////////////////////////////////////
typedef std::vector<BaseModel*> MeshList;
typedef MeshList::iterator MeshListIterator;

//////////////////////////////////////
// Class Definition
//////////////////////////////////////
class CMeshManager
{
public:
	CMeshManager(void);
	~CMeshManager(void);
	// Loads the meshes to be rendered
	bool LoadMeshes(void);

	typedef enum { eTinyX, eAnimTiny, eMultiAnimTiny, eTeapot, eWell, eCherryTreeLow } EMeshType;

private:
	LPDIRECT3DDEVICE9					m_device;
	MeshList							m_arrMeshes;
	D3DMATERIAL9						m_teapotMaterial;
public:
	inline MeshList* GetMeshList(void) {return &m_arrMeshes;}
	inline void SetDevice(LPDIRECT3DDEVICE9 device) {m_device=device;}
	//void GroundClampObjects(CTerrain &Terrain);
	void GetMesh(EMeshType meshName, BaseModel **retMesh);
	void Update( LPDIRECT3DDEVICE9 device, float elapsedMillis );
};