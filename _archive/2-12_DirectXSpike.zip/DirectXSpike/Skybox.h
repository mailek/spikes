#pragma once
//////////////////////////////////////////////////////////////////////////
// Skybox.h - 2011 Matthew Alford
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Includes
//////////////////////////////////////

//////////////////////////////////////
// Forward Declarations
//////////////////////////////////////
class CShaderManager;
class CCamera;

//////////////////////////////////////
// Class Definition
//////////////////////////////////////
class CSkybox : public IRenderable
{
public:
	CSkybox(void);
	~CSkybox(void);
	bool LoadSkyDome(LPDIRECT3DDEVICE9 device, float radius, UINT slices, UINT stacks);
	inline void SetCameraObjectToFollow(CCamera* camera) {m_pCamera = camera;}
	
	virtual void Render(LPDIRECT3DDEVICE9 device, CShaderManager &shaderMgr);
	virtual D3DXMATRIX GetWorldTransform();
	virtual bool IsTransparent() {return false;}
	virtual void SetLastRenderFrame(UINT frameNum) {};
	virtual UINT GetLastRenderFrame() {return 0;}
	virtual D3DXVECTOR4 GetBoundingSphere() {return D3DXVECTOR4(0,0,0,0);}

private:
	LPDIRECT3DTEXTURE9		m_texSkyTexture;
	LPD3DXMESH				m_mesh;
	D3DMATERIAL9			m_skyMaterial;
	CCamera*				m_pCamera;			// pointer to camera object to follow

};