#include "StdAfx.h"
#include "Camera.h"
#include "Player.h"
#include "Terrain.h"

const float CCamera::FARPLANEDISTANCE	= 1600.0f;
const float CCamera::NEARPLANEDISTANCE	= 1.0f;
const float CCamera::VERTFOVANGLERADS   = D3DX_PI * 0.5f;

CCamera::CCamera(void) : m_pPlayer(NULL),
						m_pTerrain(NULL),
						m_aspectRatio(0.0f)
{
	::ZeroMemory(m_vecPos, sizeof(m_vecPos));
	::ZeroMemory(m_vecTargetLookAt, sizeof(m_vecTargetLookAt));

	m_vecX = D3DXVECTOR3(1,0,0);
	m_vecY = D3DXVECTOR3(0,1,0);
	m_vecZ = D3DXVECTOR3(0,0,1);
	m_vecPosLocalOffset = D3DXVECTOR3(-5.0f, 12.0f, -10.0f);
	m_vecLookAtLocalOffset = D3DXVECTOR3(0.0f, 0.0f, 25.0f);

	D3DXMatrixIdentity(&m_matProjection);
	D3DXMatrixIdentity(&m_viewMatrix);
}

void CCamera::Update(float elapsedMillis)
 {
	D3DXVECTOR3 augPos =  D3DXVECTOR3(0,0,m_vecPosLocalOffset.z);
	
	if(m_pPlayer)
	{
		D3DXMATRIX yRotate, xRotate;
		D3DXMatrixRotationX(&xRotate, m_pPlayer->GetRotationRadians().x);
		D3DXMatrixRotationY(&yRotate, m_pPlayer->GetRotationRadians().y);
		
		D3DXVec3TransformCoord(&augPos, &augPos, &xRotate);
		augPos += D3DXVECTOR3(m_vecPosLocalOffset.x, 0, 0);
		D3DXVec3TransformCoord(&augPos, &augPos, &yRotate);
		

		augPos += m_pPlayer->GetPosition3D();
		augPos += D3DXVECTOR3(0,m_vecPosLocalOffset.y, 0);

		// Ground clamp augmented position to get final position
		/*float clampedY = m_pTerrain->GetTerrainHeightAtXZ(augPos.x, augPos.z) + 1.5f;
		if(augPos.y < clampedY)
		{
			float diffY = clampedY - augPos.y;
			m_vecTargetLookAt.y += 0.5f*diffY;
			augPos.y = clampedY + 0.5f*diffY;
		}*/

		m_vecPos = augPos;

		m_vecTargetLookAt = D3DXVECTOR3(0,0,m_vecLookAtLocalOffset.z);
		D3DXVec3TransformCoord(&m_vecTargetLookAt, &m_vecTargetLookAt, &xRotate);
		m_vecTargetLookAt += D3DXVECTOR3(m_vecPosLocalOffset.x, 0, 0);
		D3DXVec3TransformCoord(&m_vecTargetLookAt, &m_vecTargetLookAt, &yRotate);
		m_vecTargetLookAt += m_pPlayer->GetPosition3D();
		m_vecTargetLookAt += D3DXVECTOR3(0,m_vecPosLocalOffset.y, 0);
	}

	
	
	//m_pPlayer->GetPosition3D() + m_vecLookAtLocalOffset;

	D3DXMatrixLookAtLH(&m_viewMatrix, &m_vecPos, &m_vecTargetLookAt, &D3DXVECTOR3(0,1,0));
	m_vecX = D3DXVECTOR3(m_viewMatrix._11, m_viewMatrix._21, m_viewMatrix._31); // right axis
	m_vecY = D3DXVECTOR3(m_viewMatrix._12, m_viewMatrix._22, m_viewMatrix._32); // up axis
	m_vecZ = D3DXVECTOR3(m_viewMatrix._13, m_viewMatrix._23, m_viewMatrix._33); // look axis

	// renormalize the unit vectors
	//D3DXVec3Normalize(&m_vecZ, &m_vecZ);
	//D3DXVec3Cross(&m_vecWorldUp, &m_vecLook, &m_vecRight);
	//D3DXVec3Normalize(&m_vecY, &m_vecY);
	//D3DXVec3Cross(&m_vecRight, &m_vecWorldUp, &m_vecLook);
	//D3DXVec3Normalize(&m_vecX, &m_vecX);
}