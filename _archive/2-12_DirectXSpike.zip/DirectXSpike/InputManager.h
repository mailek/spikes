#pragma once
//////////////////////////////////////////////////////////////////////////
// InputManager.h - 2011 Matthew Alford
// ## Buffers raw input messages and translates to game key codes
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Includes
//////////////////////////////////////
#include "Keyboard.h"

//////////////////////////////////////
// Forward Declarations
//////////////////////////////////////
class CPlayer;
interface IGameState;

//////////////////////////////////////
// Class Definition
//////////////////////////////////////
class CInputManager
{
public:
	CInputManager(void);
	~CInputManager(void);

private:
	D3DXVECTOR2 m_bufferMouse;
	bool		m_bCameraAttachMode;
	IGameState *m_gameState;
	WORD		m_buttonBuffer;
	WORD		m_prevFrameButtonBuffer;

public:
	void Setup();
	void Update();
	
	inline void MouseMoved(int dX, int dY) {m_bufferMouse.x += (float)dX; m_bufferMouse.y += (float)dY;}	
	inline void KeyDown( UINT keycode ) {UINT virtualkey = TranslateKey( keycode ); m_buttonBuffer |= (1<<(virtualkey-1));}
	inline void KeyUp( UINT keycode ) {UINT virtualkey = TranslateKey( keycode ); m_buttonBuffer &= ~(1<<(virtualkey-1));}
	inline D3DXVECTOR2 GetMousePos() {return m_bufferMouse;}
	inline void SetGameState(IGameState* gs) {m_gameState = gs;}

};