#include "stdafx.h"

#include "SceneManager.h"
#include "ShaderManager.h"
#include "Terrain.h"
#include "MathUtil.h"
#include "vertextypes.h"


struct QuadTreeNode {
	D3DXMATRIX					worldTransform;
	D3DXVECTOR4					sphereBounds;  // expressed as x,y,z,radius
	D3DXVECTOR3					ABBMin;
	D3DXVECTOR3					ABBMax;
	unsigned int				index;
	unsigned int				parentIndex;
	std::vector<IRenderable*>   *objects;
	QuadTreeNode() : objects(NULL){};
};

static const int QUADTREEDEPTH					= 5;
static const int DEPTHOFSPHERETEST				= 4;
static const bool OptimizeCollisionFor2D		= true;
static const int FARPLANEDISTMOD				= 500;

inline int GetQuadTreeSize(void)
{
	static int nQuadTreeSize = 0;
	if(nQuadTreeSize == 0)
	{
		// calculate quad tree size
		float total(0.0f);
		for(int i=0; i<=QUADTREEDEPTH; i++)
			total += pow(4.0f, i);

		nQuadTreeSize = (int)floor(total);
	}

	return nQuadTreeSize;
}

//////////////////////////////////////////////////////////////////////////
// Setup Functions
//////////////////////////////////////////////////////////////////////////

CSceneManager::CSceneManager(void) : m_pCamera(NULL),
									m_debugMesh(NULL),
									m_bDrawDebugQuadTree(false),
									m_currentFrame(0),
									m_clipStrategy(FRUSTUMCLIP)
{
	::ZeroMemory(&m_quadTreeArray, sizeof(m_quadTreeArray));
}

CSceneManager::~CSceneManager(void)
{
	COM_SAFERELEASE(m_VBDebugQuadTree);
	COM_SAFERELEASE(m_debugMesh);

	int quadSize = GetQuadTreeSize();
	for(int i = 0; i < quadSize; i++)
	{
		if(m_quadTreeArray[i] == NULL)
			continue;

		PTR_SAFEDELETE(m_quadTreeArray[i]->objects);
		PTR_SAFEDELETE(m_quadTreeArray[i]);
	}
}

void CSceneManager::Setup(LPDIRECT3DDEVICE9 device, CTerrain& terrain)
{
	CreateDebugRenderBox(device);

	// build quad tree
	QuadTreeNode* root = new QuadTreeNode();
	terrain.CalculateBoundingBox(root->ABBMax, root->ABBMin);
	
	const float terrainWidth = fabs(root->ABBMax.x - root->ABBMin.x);
	const float terrainDepth = fabs(root->ABBMax.z - root->ABBMin.z);
	const float terrainHeight = fabs(root->ABBMax.y - root->ABBMin.y);

	D3DXMATRIX worldMatrix;
	D3DXMatrixIdentity(&worldMatrix);
	worldMatrix._11 *= terrainWidth;
	worldMatrix._22 *= terrainHeight;
	worldMatrix._33 *= terrainDepth;

	D3DXMATRIX localTransform;
	D3DXMatrixIdentity(&localTransform);
	D3DXMatrixTranslation(&localTransform, 0, root->ABBMin.y, 0);
	worldMatrix *= localTransform;

	root->worldTransform = worldMatrix;
	
	root->index = 0;
	root->parentIndex = 0;
	m_quadTreeArray[0] = root;
	
	std::vector<QuadTreeNode*> newParents, oldParents;
	oldParents.push_back(root);
	long quadCount(1);
		
	for(int i = 0; i < QUADTREEDEPTH; i++)
	{
		for(std::vector<QuadTreeNode*>::iterator it = oldParents.begin(), _it = oldParents.end(); it != _it; it++)
			BuildNextQuadTreeDepth((*it), quadCount, newParents, terrain, i == QUADTREEDEPTH-1); // index to next item
		
		oldParents = newParents;
		newParents.clear();
	}

}

void CSceneManager::BuildNextQuadTreeDepth(const QuadTreeNode *parent, long &quadCount, std::vector<QuadTreeNode*> &newParents, CTerrain& terrain, bool leafDepth)
{
	D3DXMATRIX scaleTransform;
	D3DXMatrixScaling(&scaleTransform, 0.5f, 1.0f, 0.5f); // new scale for the inner quads
	D3DXMATRIX parentWorld = parent->worldTransform; // strip the y scale & translate from the parent transform since we'll calculate per quad
	parentWorld._42 = 0.0f;
	parentWorld._22 = 1.0f;
 
	const float terrainWidth = fabs(parent->ABBMax.x - parent->ABBMin.x);
	const float terrainDepth = fabs(parent->ABBMax.z - parent->ABBMin.z);
	const float abbSphereBoundRadius = 0.5f*sqrt(pow(terrainWidth,2) + pow(terrainDepth,2));

	float abbYSink(0.0), abbHeight(0.0);
	if(leafDepth)
	{
		abbYSink = 50.0f;  // need to sink the quad box in the ground to account for low spots in middle of quad that are missed by the corner ground clamp
		abbHeight = abbYSink + 50.0f;
	}
	else
	{
		abbYSink = 500.0f;  
		abbHeight = abbYSink + 500.0f;
	}

	for(int i = 0; i < 4; i++)
	{
		QuadTreeNode* newSubNode = new QuadTreeNode();
		newSubNode->index = quadCount;
		newSubNode->parentIndex = parent->index;
		float parentCenterXOffset(0.0f), parentCenterZOffset(0.0f);
		
		if(i == 0)
		{
			// upper left corner
			newSubNode->ABBMin = parent->ABBMin - D3DXVECTOR3(0, 0, -terrainDepth/2.0f);
			newSubNode->ABBMax = parent->ABBMax - D3DXVECTOR3(terrainWidth/2.0f, 0, 0);
			parentCenterXOffset = -terrainWidth/4.0f;
			parentCenterZOffset = terrainDepth/4.0f;

		} else if(i == 1)
		{
			// upper right corner
			newSubNode->ABBMin = parent->ABBMin - D3DXVECTOR3(-terrainWidth/2.0f, 0, -terrainDepth/2.0f);
			newSubNode->ABBMax = parent->ABBMax;
			parentCenterXOffset = terrainWidth/4.0f;
			parentCenterZOffset = terrainDepth/4.0f;
			
		} else if(i == 2)
		{
			// lower left corner
			newSubNode->ABBMin = parent->ABBMin;
			newSubNode->ABBMax = parent->ABBMax - D3DXVECTOR3(terrainWidth/2.0f, 0, terrainDepth/2.0f);
			parentCenterXOffset = -terrainWidth/4.0f;
			parentCenterZOffset = -terrainDepth/4.0f;
		}
		else
		{
			// lower right corner
			newSubNode->ABBMin = parent->ABBMin - D3DXVECTOR3(-terrainWidth/2.0f, 0, 0);
			newSubNode->ABBMax = parent->ABBMax - D3DXVECTOR3(0, 0, terrainDepth/2.0f);
			parentCenterXOffset = terrainWidth/4.0f;
			parentCenterZOffset = -terrainDepth/4.0f;
		}
		
		float yMin = terrain.GetTerrainHeightAtXZ(newSubNode->ABBMin.x, newSubNode->ABBMin.z);
		yMin = min(yMin, terrain.GetTerrainHeightAtXZ(newSubNode->ABBMin.x + terrainWidth/2.0f, newSubNode->ABBMin.z));
		yMin = min(yMin, terrain.GetTerrainHeightAtXZ(newSubNode->ABBMin.x, newSubNode->ABBMin.z + terrainDepth/2.0f));
		yMin = min(yMin, terrain.GetTerrainHeightAtXZ(newSubNode->ABBMin.x + terrainWidth/2.0f, newSubNode->ABBMin.z + terrainDepth/2.0f));

		newSubNode->ABBMin.y = yMin - abbYSink;
		newSubNode->ABBMax.y = newSubNode->ABBMin.y + abbHeight;
		D3DXMATRIX localTransform; // calculate the offset from the parent's local space
		D3DXMatrixTranslation(&localTransform, parentCenterXOffset, newSubNode->ABBMin.y, parentCenterZOffset);

		D3DXMatrixScaling(&scaleTransform, 0.5f, fabs(newSubNode->ABBMin.y - newSubNode->ABBMax.y), 0.5f); 
		newSubNode->worldTransform = scaleTransform * parentWorld * localTransform;
		D3DXVECTOR3 centerPos(0,0,0);
		D3DXVec3TransformCoord(&centerPos, &centerPos, &newSubNode->worldTransform);
		newSubNode->sphereBounds = D3DXVECTOR4(centerPos, abbSphereBoundRadius);

		m_quadTreeArray[newSubNode->index] = newSubNode;
		assert(MAXQUADS >= newSubNode->index);
		newParents.push_back(m_quadTreeArray[newSubNode->index]);

		quadCount++;
	}
}

void CSceneManager::CreateDebugRenderBox(LPDIRECT3DDEVICE9 device)
{
	// Create the lines
	COM_SAFERELEASE(m_VBDebugQuadTree);
	HRESULT hr = device->CreateVertexBuffer(46*sizeof(DebugQuadTreeVertex), D3DUSAGE_WRITEONLY, DebugQuadTreeVertex::FVF, D3DPOOL_MANAGED, &m_VBDebugQuadTree, 0);
	if(FAILED(hr))
		return;

	DebugQuadTreeVertex* coord = NULL;
	hr = m_VBDebugQuadTree->Lock(0, 0, (void**)&coord, 0);
	if(FAILED(hr))
		return;

	const float whiteBoxRadius = 0.499f;
	// front face
	coord[0]._p  = D3DXVECTOR3(-whiteBoxRadius, 2*whiteBoxRadius, -whiteBoxRadius);
	coord[1]._p  = D3DXVECTOR3(whiteBoxRadius, 2*whiteBoxRadius, -whiteBoxRadius);
	coord[2]._p  = D3DXVECTOR3(whiteBoxRadius, 0, -whiteBoxRadius);
	coord[3]._p  = D3DXVECTOR3(-whiteBoxRadius, 0, -whiteBoxRadius);
	
	// left face
	coord[4]._p  = D3DXVECTOR3(-whiteBoxRadius, 0, whiteBoxRadius);
	coord[5]._p  = D3DXVECTOR3(-whiteBoxRadius, 2*whiteBoxRadius, whiteBoxRadius);
	coord[6]._p  = D3DXVECTOR3(-whiteBoxRadius, 2*whiteBoxRadius, -whiteBoxRadius);
	coord[7]._p  = D3DXVECTOR3(-whiteBoxRadius, 0, -whiteBoxRadius);

	// bottom face
	coord[8]._p  = D3DXVECTOR3(whiteBoxRadius, 0, -whiteBoxRadius);
	coord[9]._p  = D3DXVECTOR3(whiteBoxRadius, 0, whiteBoxRadius);
	coord[10]._p  = D3DXVECTOR3(-whiteBoxRadius, 0, whiteBoxRadius);
	coord[11]._p  = D3DXVECTOR3(-whiteBoxRadius, 0, -whiteBoxRadius);

	// move to other side
	coord[12]._p  = D3DXVECTOR3(whiteBoxRadius, 0, -whiteBoxRadius);
	coord[13]._p  = D3DXVECTOR3(whiteBoxRadius, 2*whiteBoxRadius, -whiteBoxRadius);
	coord[14]._p  = D3DXVECTOR3(whiteBoxRadius, 2*whiteBoxRadius, whiteBoxRadius);

	// top face
	coord[15]._p  = D3DXVECTOR3(-whiteBoxRadius, 2*whiteBoxRadius, whiteBoxRadius);
	coord[16]._p  = D3DXVECTOR3(-whiteBoxRadius, 2*whiteBoxRadius, -whiteBoxRadius);
	coord[17]._p  = D3DXVECTOR3(whiteBoxRadius, 2*whiteBoxRadius, -whiteBoxRadius);
	coord[18]._p  = D3DXVECTOR3(whiteBoxRadius, 2*whiteBoxRadius, whiteBoxRadius);

	// back face
	coord[19]._p  = D3DXVECTOR3(-whiteBoxRadius, 2*whiteBoxRadius, whiteBoxRadius);
	coord[20]._p  = D3DXVECTOR3(-whiteBoxRadius, 0, whiteBoxRadius);
	coord[21]._p  = D3DXVECTOR3(whiteBoxRadius, 0, whiteBoxRadius);
	coord[22]._p  = D3DXVECTOR3(whiteBoxRadius, 2*whiteBoxRadius, whiteBoxRadius);

	for(int i = 0; i < 23; i++) coord[i]._c  = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);

	const float yellowBoxRadius = 0.499f;
	// front face
	coord[23]._p  = D3DXVECTOR3(-yellowBoxRadius, 2*yellowBoxRadius, -yellowBoxRadius);
	coord[24]._p  = D3DXVECTOR3(yellowBoxRadius, 2*yellowBoxRadius, -yellowBoxRadius);
	coord[25]._p  = D3DXVECTOR3(yellowBoxRadius, 0, -yellowBoxRadius);
	coord[26]._p  = D3DXVECTOR3(-yellowBoxRadius, 0, -yellowBoxRadius);
	
	// left face
	coord[27]._p  = D3DXVECTOR3(-yellowBoxRadius, 0, yellowBoxRadius);
	coord[28]._p  = D3DXVECTOR3(-yellowBoxRadius, 2*yellowBoxRadius, yellowBoxRadius);
	coord[29]._p  = D3DXVECTOR3(-yellowBoxRadius, 2*yellowBoxRadius, -yellowBoxRadius);
	coord[30]._p  = D3DXVECTOR3(-yellowBoxRadius, 0, -yellowBoxRadius);

	// bottom face
	coord[31]._p  = D3DXVECTOR3(yellowBoxRadius, 0, -yellowBoxRadius);
	coord[32]._p  = D3DXVECTOR3(yellowBoxRadius, 0, yellowBoxRadius);
	coord[33]._p  = D3DXVECTOR3(-yellowBoxRadius, 0, yellowBoxRadius);
	coord[34]._p  = D3DXVECTOR3(-yellowBoxRadius, 0, -yellowBoxRadius);

	// move to other side
	coord[35]._p  = D3DXVECTOR3(yellowBoxRadius, 0, -yellowBoxRadius);
	coord[36]._p  = D3DXVECTOR3(yellowBoxRadius, 2*yellowBoxRadius, -yellowBoxRadius);
	coord[37]._p  = D3DXVECTOR3(yellowBoxRadius, 2*yellowBoxRadius, yellowBoxRadius);

	// top face
	coord[38]._p  = D3DXVECTOR3(-yellowBoxRadius, 2*yellowBoxRadius, yellowBoxRadius);
	coord[39]._p  = D3DXVECTOR3(-yellowBoxRadius, 2*yellowBoxRadius, -yellowBoxRadius);
	coord[40]._p  = D3DXVECTOR3(yellowBoxRadius, 2*yellowBoxRadius, -yellowBoxRadius);
	coord[41]._p  = D3DXVECTOR3(yellowBoxRadius, 2*yellowBoxRadius, yellowBoxRadius);

	// back face
	coord[42]._p  = D3DXVECTOR3(-yellowBoxRadius, 2*yellowBoxRadius, yellowBoxRadius);
	coord[43]._p  = D3DXVECTOR3(-yellowBoxRadius, 0, yellowBoxRadius);
	coord[44]._p  = D3DXVECTOR3(yellowBoxRadius, 0, yellowBoxRadius);
	coord[45]._p  = D3DXVECTOR3(yellowBoxRadius, 2*yellowBoxRadius, yellowBoxRadius);
	
	for(int i = 23; i < 46; i++) coord[i]._c  = D3DXCOLOR(1.0f, 1.0f, 0.2f, 1.0f);

	m_VBDebugQuadTree->Unlock();
}

//////////////////////////////////////////////////////////////////////////
// Update Functions
//////////////////////////////////////////////////////////////////////////

// Grabs all the objects in a given quad node index, sorts into opaque and transparent lists, and optionally get all objects from children without scrutiny
void CSceneManager::AddObjectsToRenderListsByQuadIndex(const int index, const D3DXMATRIX &viewMatrix, SceneMgrRenderList &opaque, SceneMgrSortList &transparent, bool recurseGrabChildren/*=false*/)
{
	if(m_quadTreeArray[index]->objects != NULL)
	{
		for(std::vector<IRenderable*>::iterator it = m_quadTreeArray[index]->objects->begin(), _it = m_quadTreeArray[index]->objects->end(); it != _it; it++)
		{
			// if we already rendered this object this frame then skip adding to render list (saves duplicate render of objects that are in multiple quad leaves)
			if((*it)->GetLastRenderFrame() == m_currentFrame) 
				continue;

			(*it)->SetLastRenderFrame(m_currentFrame);

			if((*it)->IsTransparent())
			{
				ZSortableRenderable zsr;
				::ZeroMemory(&zsr, sizeof(zsr));
				zsr.p = (*it);
				D3DXVECTOR3 v(0,0,0);
				D3DXVec3TransformCoord(&v, &v, &D3DXMATRIX((*it)->GetWorldTransform() * viewMatrix));
				zsr.viewSpaceZ = v.z;
				
				transparent.push_back(zsr);
			}
			else
				opaque.push_back(*it);
		}
	}

	if(recurseGrabChildren && QuadHasChildren(index))
	{
		for(long i = 4*index+1, j = 4*index+4; i <= j; i++)
		{
			AddObjectsToRenderListsByQuadIndex(i, viewMatrix, opaque, transparent, true);
		}
	}
}

void CSceneManager::FrustumRecurseCollideQuadChildren(int index, const D3DXMATRIX &viewMatrix, SceneMgrRenderList &opaque, SceneMgrSortList &transparent)
{
	static float ASPECT;        // save the camera values so we dont't calculate every time through recursion
	static float FOVANGLE;      
	static float NEARDIST;      
	static float FARDIST;       
	static D3DXVECTOR3 cameraX; 
	static D3DXVECTOR3 cameraY; 
	static D3DXVECTOR3 cameraZ;
	static int nRecursionLevel = 0;
	D3DXVECTOR3 cameraPos = m_pCamera->Get3DPosition();

	if(nRecursionLevel == 0)
	{
		ASPECT		= m_pCamera->GetAspectRatio();
		FOVANGLE	= m_pCamera->GetVerticalFoVAngleRads();
		NEARDIST	= m_pCamera->GetNearPlaneDist();
		FARDIST 	= m_pCamera->GetFarPlaneDist()-FARPLANEDISTMOD;
		cameraX		= m_pCamera->GetRightAxis();
		cameraY 	= m_pCamera->GetUpAxis();
		cameraZ		= m_pCamera->GetLookAxis();
	}

	if(!QuadHasChildren(index))
	{
		if(m_quadTreeArray[index]->objects != NULL)
			AddObjectsToRenderListsByQuadIndex(index, viewMatrix, opaque, transparent);

		return;
	}

	nRecursionLevel++;
	
	// if children then collide the frustum to each child's bound box
	for(long i = 4*index+1, j = 4*index+4; i <= j; i++)
	{
		int result(-1);
		// if at the top of the quad tree, then use sphere collision for faster results
		if(nRecursionLevel < DEPTHOFSPHERETEST)
		{
			result = Collide_SphereToFrustum(m_quadTreeArray[i]->sphereBounds, cameraPos, cameraX, cameraY, cameraZ, FOVANGLE, ASPECT, NEARDIST, FARDIST, OptimizeCollisionFor2D);
		} else
		{
			// Test by ABB (more accurate for smaller quads)
			result = Collide_ABBToFrustum(m_quadTreeArray[i]->ABBMin, m_quadTreeArray[i]->ABBMax, cameraPos, cameraX, cameraY, cameraZ, FOVANGLE, ASPECT, NEARDIST, FARDIST, OptimizeCollisionFor2D);
		}	

		if(result == COLLIDE_INTERSECT)
			FrustumRecurseCollideQuadChildren(i, viewMatrix, opaque, transparent);// if child is partially outside then add to a list of further collision checks and go to next child
		else if(result == COLLIDE_CONTAINED)
			AddObjectsToRenderListsByQuadIndex(i, viewMatrix, opaque, transparent, true); // grab all objects from child nodes without doing additonal checks on them
		//else if(result == COLLIDE_OUTSIDE)
			//continue; // if child is totally outside then go to next child
		
	}
	
	nRecursionLevel--;
}

void CSceneManager::UpdateDrawLists()
{
	if(m_pCamera == NULL)
		return;

	D3DXMATRIX currentViewSpace = m_pCamera->GetViewMatrix();
	if(m_lastViewSpace == currentViewSpace)
		return; // Camera hasn't changed, so bail

	m_currentFrame++;
	m_opaqueList.clear();
	m_transparentList.clear();
	
	for(std::vector<IRenderable*>::iterator it = m_noClipList.begin(), _it = m_noClipList.end(); it != _it; it++)
		m_opaqueList.push_back(*it);

	//m_opaqueList.sort();
	//m_opaqueList.reverse();

	// fill out the render list by traversing the quad tree and building a list of opaque and transparent objects
	// this can be found by a number of methods
	// TODO: the method chosen can be changed at runtime to compare performance settings

	D3DXMATRIX view = m_pCamera->GetViewMatrix();
	D3DXVECTOR3 cameraPos = m_pCamera->Get3DPosition();
	const int method = m_clipStrategy;

	switch(method)
	{
	case BRUTEFORCE:
		{
			// iterate through the quad tree and grab all the objects
			const int loopCnt = GetQuadTreeSize();
			for(int i = 0; i < loopCnt; i++)
				AddObjectsToRenderListsByQuadIndex(i, view, m_opaqueList, m_transparentList);

			break;
		}
	case FRUSTUMCLIP:
		{
			// start at base of quad tree and recurse through quad tree, checking for frustum collisions
			FrustumRecurseCollideQuadChildren(0, view, m_opaqueList, m_transparentList);
			break;
		}
	case CAMERAQUAD:
		{
			AddObjectsToRenderListsByQuadIndex(FindLeafQuadByPoint(cameraPos), view, m_opaqueList, m_transparentList);
			break;
		}
	default:
		break;
	}

	// sort the structure
	m_transparentList.sort();
	//m_transparentList.reverse();
	//m_transparentList.clear();
		
	m_lastViewSpace = currentViewSpace;
}

bool CSceneManager::QuadHasChildren(const long index)
{
	long i = 4*index+1;
	if(i > GetQuadTreeSize()-1 || m_quadTreeArray[i] == NULL)
		return false;

	return true;
}

int CSceneManager::FindLeafQuadByPoint(D3DXVECTOR3 point)
{
	int index(0);
	bool indexChanged(false);
	do
	{
		indexChanged = false;
		for(int subIndex = 1; subIndex < 5; subIndex++)
		{
			int newIndex = 4*index+subIndex;
			if(Collide_PointToBox(point, m_quadTreeArray[newIndex]->ABBMin, m_quadTreeArray[newIndex]->ABBMax))
			{
				index = newIndex;
				indexChanged = true;
				break;
			}
		} 
	}
	while(QuadHasChildren(index) && indexChanged);

	return index;
}


void CSceneManager::FindLeafListQuadsByBoundSphere(D3DXVECTOR4 sphere, std::vector<int> &leafIndices)
{
	leafIndices.clear();
	std::vector<int> parentsToSearch, oldParents;
	oldParents.push_back(0); // seed recursion with root index
	do // breadth first recursion
	{
		parentsToSearch.clear(); // TODO: GET RID OF NASTY VECTORS IN A RENDER CALL (TOO SLOW)
		for(std::vector<int>::iterator it = oldParents.begin(), _it = oldParents.end(); it != _it; it++)
		{
			for(int subIndex = 1; subIndex <= 4; subIndex++)
			{
				int index = 4*(*it)+subIndex;
				if(Collide_SphereToBox(sphere, m_quadTreeArray[index]->ABBMin, m_quadTreeArray[index]->ABBMax))
				{
					if(QuadHasChildren(index))
						parentsToSearch.push_back(index);
					else
						leafIndices.push_back(index);
				}
			}
		}
		oldParents = parentsToSearch;
	}
	while(oldParents.size() != 0);
}

void CSceneManager::GetOpaqueDrawListF2B(std::list<IRenderable*> &list)
{
	UpdateDrawLists();
	list.clear();
	typedef std::list<IRenderable*> RenderList;

	list = m_opaqueList;
}

void CSceneManager::GetTransparentDrawListB2F(SceneMgrSortList &list)
{
	UpdateDrawLists();
	list.clear();

	list = m_transparentList;
}

void CSceneManager::AddNonclippableObjectToScene(IRenderable* obj)
{
	m_noClipList.push_back(obj);
}

void CSceneManager::AddRenderableObjectToScene(IRenderable* obj)
{
	assert(obj);

	// find the leaf quad that contains the object's center
	D3DXVECTOR4 pos(0,0,0,1);
	D3DXVec4Transform(&pos, &pos, &obj->GetWorldTransform());
	int index = FindLeafQuadByPoint(D3DXVECTOR3(pos.x, pos.y, pos.z));
	obj->SetLastRenderFrame(m_currentFrame);

	if(m_quadTreeArray[index]->objects == NULL)
		m_quadTreeArray[index]->objects = new std::vector<IRenderable*>();
	
	m_quadTreeArray[index]->objects->push_back(obj);	

	// find the additional quad leaves that intersect the object's sphere boundary
	std::vector<int> leavesCollidingWithSphere;
	FindLeafListQuadsByBoundSphere(obj->GetBoundingSphere(), leavesCollidingWithSphere);
	
	for(std::vector<int>::iterator it = leavesCollidingWithSphere.begin(), _it = leavesCollidingWithSphere.end(); it != _it; it++)
	{
		if(*it == index) // already inserted into the position-collide leaf, later this needs to add a flag on the leaf object to identify reference vs. actual (center point)
			continue;

		if(m_quadTreeArray[*it]->objects == NULL)
			m_quadTreeArray[*it]->objects = new std::vector<IRenderable*>();

		m_quadTreeArray[*it]->objects->push_back(obj); // create a new reference
	}

}

//////////////////////////////////////////////////////////////////////////
// Render Functions
//////////////////////////////////////////////////////////////////////////

void CSceneManager::Render(LPDIRECT3DDEVICE9 device, CShaderManager &shaderMgr)
{
	if(!m_bDrawDebugQuadTree || m_pCamera == NULL)
		return;

	// render the quad tree debug lines
	shaderMgr.SetVertexShader(PASS_PRIMITIVE);
	shaderMgr.SetPixelShader(PASS_PRIMITIVE);

	shaderMgr.SetViewProjection(PASS_PRIMITIVE, m_pCamera->GetViewMatrix(), m_pCamera->GetProjectionMatrix());
	device->SetFVF(DebugQuadTreeVertex::FVF);
	device->SetTexture(0, 0);

	int index = FindLeafQuadByPoint(m_pCamera->Get3DPosition()); // find the leaf quad the camera is currently within, and display it highlighted with yellow
	for(int i = 0; i < GetQuadTreeSize(); i++)
	{
		if(m_quadTreeArray[i]==NULL)
			break;
		
		if(QuadHasChildren((long)i))
			continue;

		if(index == i)
			device->SetStreamSource(0, m_VBDebugQuadTree, 23*sizeof(DebugQuadTreeVertex), sizeof(DebugQuadTreeVertex)); // yellow box
		else
			device->SetStreamSource(0, m_VBDebugQuadTree, 0, sizeof(DebugQuadTreeVertex)); // white box

		shaderMgr.SetWorldTransform(PASS_PRIMITIVE, m_quadTreeArray[i]->worldTransform);
		device->DrawPrimitive(D3DPT_LINESTRIP, 0, 22);
		//break;
	}

	device->SetStreamSource(0, m_VBDebugQuadTree, 23*sizeof(DebugQuadTreeVertex), sizeof(DebugQuadTreeVertex));
	shaderMgr.SetWorldTransform(PASS_PRIMITIVE, m_quadTreeArray[index]->worldTransform);
	device->DrawPrimitive(D3DPT_LINESTRIP, 0, 22);
}