#pragma once
//////////////////////////////////////////////////////////////////////////
// Player.h - 2011 Matthew Alford
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Forward Declarations
//////////////////////////////////////
class CPlayer;
class CTerrain;

//////////////////////////////////////
// Class Definition
//////////////////////////////////////
class CCamera
{
public:
	CCamera(void);
	~CCamera(void) {};

private:
	D3DXVECTOR3										m_vecPos;
	D3DXVECTOR3										m_vecPosLocalOffset;
	D3DXVECTOR3										m_vecTargetLookAt;
	D3DXVECTOR3										m_vecLookAtLocalOffset;
	D3DXVECTOR3										m_vecZ; 
	D3DXVECTOR3										m_vecY; 
	D3DXVECTOR3										m_vecX;
	
	D3DXMATRIX										m_matProjection;
	D3DXMATRIX										m_viewMatrix;

	CPlayer*										m_pPlayer;  // camera needs player to do soft attach
	CTerrain*										m_pTerrain; // camera needs terrain to find ground clamp
	float											m_aspectRatio;

	static const float								FARPLANEDISTANCE;
	static const float								NEARPLANEDISTANCE;
	static const float								VERTFOVANGLERADS;

public:
	void Update(float elapsedMillis);

	inline void SetViewPort(unsigned int viewWidth, unsigned int viewHeight) { m_aspectRatio = (float)viewWidth/(float)viewHeight; D3DXMatrixPerspectiveFovLH(&m_matProjection, VERTFOVANGLERADS, m_aspectRatio, NEARPLANEDISTANCE, FARPLANEDISTANCE); }
	inline D3DXMATRIX GetViewMatrix() { return m_viewMatrix; }
	inline D3DXVECTOR3 Get3DPosition() { return  m_vecPos; } 
	inline void Set3DPosition(D3DXVECTOR3 &pos) {m_vecPos = pos;}
	inline void SetPlayerForFollow(CPlayer *player) {m_pPlayer = player;}
	inline D3DXMATRIX GetProjectionMatrix() {return m_matProjection;}
	inline void SetTerrainToClamp(CTerrain *terrain) {m_pTerrain = terrain;}
	inline float GetFarPlaneDist() {return FARPLANEDISTANCE;}
	inline float GetNearPlaneDist() {return NEARPLANEDISTANCE;}
	inline float GetVerticalFoVAngleRads() {return VERTFOVANGLERADS;}
	inline float GetAspectRatio() {return m_aspectRatio;}
	inline D3DXVECTOR3 GetLookAxis() {return m_vecZ;}
	inline D3DXVECTOR3 GetRightAxis() {return m_vecX;}
	inline D3DXVECTOR3 GetUpAxis() {return m_vecY;}
};