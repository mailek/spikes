#pragma once
//////////////////////////////////////////////////////////////////////////
// StdAfx.h - 2011 Matthew Alford
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Includes
//////////////////////////////////////
#define WIN32_LEAN_AND_MEAN // Exclude rarely-used stuff from Windows headers
#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <vector>
#include <assert.h>
#include <map>
#include <list>
#include <math.h>

//////////////////////////////////////
// Constants
//////////////////////////////////////
#define NULL			0
#define BITS_PER_BYTE	(16)

//////////////////////////////////////
// Forward Declarations
//////////////////////////////////////
class CShaderManager;

interface IRenderable{	// temporary solution until I get templates written
	virtual void Render(LPDIRECT3DDEVICE9 device, CShaderManager &shaderMgr) =0;
	virtual D3DXMATRIX GetWorldTransform() =0;
	virtual bool IsTransparent() =0;
	virtual void SetLastRenderFrame(UINT frameNum) =0;
	virtual UINT GetLastRenderFrame() =0;
	virtual D3DXVECTOR4 GetBoundingSphere() =0;
};

extern inline void COM_SAFERELEASE(IUnknown* ptr);

//////////////////////////////////////
// Macros
//////////////////////////////////////

/* memory */
#define PTR_SAFEDELETE(p) \
	{ delete p; p = NULL;	}

/* utility */
#define cnt_of_array(type) \
	( sizeof(type) / sizeof(type[0]) )

#define VERIFY_SUCCESS(com) \
	if( FAILED(com) ) \
		{assert(false);}

//////////////////////////////////////
// Events
//////////////////////////////////////
#define EVT_UPDATE		1
#define EVT_RENDER		2
#define EVT_INIT		3
#define EVT_DESTROY		4
#define EVT_GETPLAYER	5
#define EVT_KEYUP		6
#define EVT_KEYDOWN		7
#define EVT_MOUSE_MOVED	8