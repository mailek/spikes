#include "stdafx.h"
#include "mathutil.h"

//////////////////////////////////////////////////////////////////////////
// Math Functions
//////////////////////////////////////////////////////////////////////////
float frand(void)
{
	return (float)rand()/(float)RAND_MAX;
}

float lerp(float x, float x1, float s)
{
	return x + s*(x1-x);
}

float fmax(float a, float b )
{
	return( a > b ? a : b );
}

float fmin(float a, float b )
{
	return( a < b ? a : b );
}

float fclamp(float x, float min, float max)
{
	return x < min ? min : (x > max ? max : x);
}

bool fcompare(float a, float b)
{
	return (::fabs(a-b) < FLT_EPSILON);
}

//////////////////////////////////////////////////////////////////////////
// Collision Functions
//////////////////////////////////////////////////////////////////////////
bool Collide_PointToBox(const D3DXVECTOR3 &p, const D3DXVECTOR3 &abbMin, const D3DXVECTOR3 &abbMax)
{
	return abbMax.x >= p.x && abbMax.y >= p.y && abbMax.z >= p.z &&
		abbMin.x <= p.x && abbMin.y <= p.y && abbMin.z <= p.z;
}

bool Collide_SphereToBox(const D3DXVECTOR4 &s, const D3DXVECTOR3 &abbMin, const D3DXVECTOR3 &abbMax)
{
	return abbMax.x >= s.x - s.w && abbMax.y >= s.y - s.w && abbMax.z >= s.z - s.w &&
		abbMin.x <= s.x + s.w && abbMin.y <= s.y + s.w && abbMin.z <= s.z + s.w;
}

// this argument list could probably be cleaned up by using a view matrix and projection matrix, and extracting the values within
bool Collide_PointToFrustum(D3DXVECTOR3 &testPt, D3DXVECTOR3 &cameraPos, D3DXVECTOR3 cameraX, D3DXVECTOR3 cameraY, D3DXVECTOR3 cameraZ, float FOVANGLE, float ASPECT, float NEARDIST, float FARDIST, bool ignoreY /*= false*/)
{
	// find the vector from the camera to the test point
	D3DXVECTOR3 v = testPt - cameraPos;
	
	// find the test points distance along the camera Z axis 
	D3DXVECTOR3 tempZ;
	if(ignoreY)
	{
		tempZ = D3DXVECTOR3(cameraZ.x, 0, cameraZ.z);
		D3DXVec3Normalize(&tempZ, &tempZ);
	}
	else
		tempZ = cameraZ;
		
	float dZ = D3DXVec3Dot(&v, &tempZ);
	
	// calculate the width and height of the view frustum at the calculated Z distance
	// h = pc.z*2*tan(vertFovAngle/2)    w = h * widthRatio
	static float fovTang = tanf(0.5f*FOVANGLE); // this optmization will limit the ability to change FoV angle during runtime
	float height = dZ*fovTang;
	float width = height * ASPECT;

	// test if x is outside the width at the calcuated Z distance
	float dX = D3DXVec3Dot(&v, &cameraX);
	if(dX > width || dX < -width)
		return false;

	// if testing in 3D (octtree) then test Y height
	if(!ignoreY)
	{
		float dY = D3DXVec3Dot(&v, &cameraY);
		if(dY > height || dY < -height)
			return false;
	}

	return true;
}


int Collide_ABBToFrustum(const D3DXVECTOR3 testABBMin, 
						 const D3DXVECTOR3 testABBMax, 
						 D3DXVECTOR3 &cameraPos, 
						 D3DXVECTOR3 cameraX, 
						 D3DXVECTOR3 cameraY, 
						 D3DXVECTOR3 cameraZ, 
						 float FOVANGLE, 
						 float ASPECT, 
						 float NEARDIST, 
						 float FARDIST, 
						 bool bTest2DXZ /*= false*/)
{
		D3DXVECTOR3 testPt;
		int inCnt(0), outCnt(0);
		int nCheckVerts(8);
		if(bTest2DXZ)
			nCheckVerts = 4;

		// for frustum clip check all AAB points against frustum volume in clip space
		for(int k = 0; k < nCheckVerts; k++)
		{
			testPt = testABBMin;
			if(k & 0x01)
				testPt.x = testABBMax.x;
			if(k & 0x02)
				testPt.z = testABBMax.z;
			if(k & 0x04)
				testPt.y = testABBMax.y;
		
			if(Collide_PointToFrustum(testPt, cameraPos, cameraX, cameraY, cameraZ, FOVANGLE, ASPECT, NEARDIST, FARDIST, bTest2DXZ))
				inCnt++;
			else
				outCnt++;

			if(inCnt > 0 && outCnt > 0)
				break;
		}	
		
		if(inCnt > 0 && outCnt > 0)
			return COLLIDE_INTERSECT;
		else if(outCnt > 0)
			return COLLIDE_OUTSIDE;
		else // totally inside
			return COLLIDE_CONTAINED;
}

int Collide_SphereToFrustum(D3DXVECTOR4 spherePosAndRadius, D3DXVECTOR3 cameraPos, D3DXVECTOR3 cameraX, D3DXVECTOR3 cameraY, D3DXVECTOR3 cameraZ, float FOVANGLE, float ASPECT, float NEARDIST, float FARDIST, bool bTest2DXZ)
{
	// find the vector from the camera to the test point
	D3DXVECTOR3 v = D3DXVECTOR3(spherePosAndRadius.x, spherePosAndRadius.y, spherePosAndRadius.z) - cameraPos;
	
	// find the test points distance along the camera Z axis 
	D3DXVECTOR3 tempZ;
	if(bTest2DXZ)
	{
		tempZ = D3DXVECTOR3(cameraZ.x, 0, cameraZ.z);
		D3DXVec3Normalize(&tempZ, &tempZ);
	}
	else
		tempZ = cameraZ;
		
	float dZ = D3DXVec3Dot(&v, &tempZ);

	// if the z is not inside the near and far planes then reject
	if(dZ > FARDIST+spherePosAndRadius.w || dZ < NEARDIST-spherePosAndRadius.w)
		return COLLIDE_OUTSIDE;
	
	
	// calculate the width and height of the view frustum at the calculated Z distance
	// h = pc.z*2*tan(vertFovAngle/2)    w = h * widthRatio
	static float fovTang = tanf(0.5f*FOVANGLE); // this optmization will limit the ability to change FoV angle during runtime
	static float sphereFactorY = 1.0f/cos(0.5f*FOVANGLE);
	static float sphereFactorX = 1.0f/cos(0.5f*FOVANGLE*ASPECT);

	float height = dZ*fovTang;
	float width = height * ASPECT;

	// test if x is outside the width at the calcuated Z distance
	float dX = D3DXVec3Dot(&v, &cameraX);
	float modRadius = sphereFactorX * spherePosAndRadius.w;
	if(dX > width+modRadius || dX < -width-modRadius)
		return COLLIDE_OUTSIDE;

	// if testing in 3D (octtree) then test Y height
	if(!bTest2DXZ)
	{
		float dY = D3DXVec3Dot(&v, &cameraY);
		modRadius = sphereFactorY * spherePosAndRadius.w;
		if(dY > height+modRadius || dY < -height-modRadius)
			return COLLIDE_OUTSIDE;
	}

	return COLLIDE_INTERSECT;
}