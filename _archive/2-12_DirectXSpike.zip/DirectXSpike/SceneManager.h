#pragma once
//////////////////////////////////////////////////////////////////////////
// SceneManager.h - 2011 Matthew Alford
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Forward Declarations
//////////////////////////////////////
class CCamera;
struct QuadTreeNode;
class CTerrain;

//////////////////////////////////////
// Type Definitions
//////////////////////////////////////

typedef class ZSortableRenderable{
public:
	IRenderable*	p;
	float			viewSpaceZ;
	bool operator<(ZSortableRenderable &comp) {return viewSpaceZ < comp.viewSpaceZ;}
} ZSR;

typedef std::list<ZSortableRenderable> SceneMgrSortList;
typedef std::list<IRenderable*> SceneMgrRenderList;

//////////////////////////////////////
// Constants
//////////////////////////////////////

static const long		MAXQUADS = 87381;

enum {
	BRUTEFORCE, 
	FRUSTUMCLIP, 
	CAMERAQUAD
};

enum { 
	RENDER_TERRAIN, 
	RENDER_SKY 
};

//////////////////////////////////////
// Class Definition
//////////////////////////////////////
class CSceneManager : public IRenderable
{
public:
	CSceneManager(void);
	~CSceneManager(void);

private:
	SceneMgrRenderList			m_opaqueList;
	SceneMgrSortList			m_transparentList;
	std::vector<IRenderable*>	m_noClipList;
	LPDIRECT3DVERTEXBUFFER9		m_VBDebugQuadTree; // debug lines for the quad tree
	CCamera						*m_pCamera;
	LPD3DXMESH					m_debugMesh;
	QuadTreeNode*				m_quadTreeArray[MAXQUADS];
	bool						m_bDrawDebugQuadTree;              // flag to render or hide quad tree lines
	D3DXMATRIX					m_lastViewSpace;
	UINT						m_currentFrame;
	int							m_clipStrategy;		// the current clip strategy for building a render list of objects

	void CreateDebugRenderBox(LPDIRECT3DDEVICE9 device);
	void BuildNextQuadTreeDepth(const QuadTreeNode *parent, long &quadCount, std::vector<QuadTreeNode*> &newParents, CTerrain& terrain, bool leafDepth);
	bool QuadHasChildren(const long index);
	int FindLeafQuadByPoint(D3DXVECTOR3 point);
	void FindLeafListQuadsByBoundSphere(D3DXVECTOR4 sphere, std::vector<int> &leafIndices);
	void UpdateDrawLists();

public:
	void GetOpaqueDrawListF2B(SceneMgrRenderList &list);
	void GetTransparentDrawListB2F(SceneMgrSortList &list);
	void AddRenderableObjectToScene(IRenderable* obj);
	void AddNonclippableObjectToScene(IRenderable* obj);
	void Setup(LPDIRECT3DDEVICE9 device, CTerrain& terrain);
	void AddObjectsToRenderListsByQuadIndex(const int index, const D3DXMATRIX &viewMatrix, SceneMgrRenderList &opaque, SceneMgrSortList &transparent, bool recurseGrabChildren=false);
	void FrustumRecurseCollideQuadChildren(int index, const D3DXMATRIX &viewMatrix, SceneMgrRenderList &opaque, SceneMgrSortList &transparent);
	
	inline void DrawDebugQuadTree(bool draw) {m_bDrawDebugQuadTree = draw;}
	inline void SetNextClipStrategy(int strategy = -1) { if(strategy >= 0) m_clipStrategy = strategy; else { m_clipStrategy++; m_clipStrategy = m_clipStrategy > CAMERAQUAD ? BRUTEFORCE : m_clipStrategy; } }
	inline void SetCamera(CCamera *camera) {m_pCamera = camera;}
	
	virtual D3DXMATRIX GetWorldTransform() {D3DXMATRIX worldMatrix;	D3DXMatrixIdentity(&worldMatrix); return worldMatrix;}
	virtual void Render(LPDIRECT3DDEVICE9 device, CShaderManager &shaderMgr);
	virtual bool IsTransparent() {return false;}
	virtual void SetLastRenderFrame(UINT frameNum) {};
	virtual UINT GetLastRenderFrame() {return 0;}
	virtual D3DXVECTOR4 GetBoundingSphere() {return D3DXVECTOR4(0,0,0,0);}
};