#include "StdAfx.h"
#include "Skybox.h"
#include "ShaderManager.h"
#include "Camera.h"
#include "vertextypes.h"

//////////////////////////////////////////////////////////////////////////
// Setup Functions
//////////////////////////////////////////////////////////////////////////

CSkybox::CSkybox(void) : m_texSkyTexture(NULL),
						m_mesh(NULL),
						m_pCamera(NULL)
{
}

CSkybox::~CSkybox(void)
{
}

bool CSkybox::LoadSkyDome(LPDIRECT3DDEVICE9 device, float radius, UINT slices, UINT stacks)
{
	HRESULT hr = D3DXCreateTextureFromFile(device, "Resources\\skyTexture.dds", &m_texSkyTexture);
	if(FAILED(hr))
		return false;

	hr = D3DXCreateSphere(device, radius, slices, stacks, &m_mesh, NULL);
	if(FAILED(hr))
		return false;
	LPD3DXMESH texturedMesh;
    hr = m_mesh->CloneMeshFVF(D3DXMESH_SYSTEMMEM, D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1, device, &texturedMesh);
	if(FAILED(hr))
		return false;
    m_mesh->Release();
	m_mesh = texturedMesh;

    // lock the vertex buffer & fill out the new uv's
    SkydomeVertex* vertices;
    texturedMesh->LockVertexBuffer(0, (void**)&vertices);
	int numVerts=m_mesh->GetNumVertices();

	// loop through the vertices
	for (int i=0;i<numVerts;i++) 
	{
		// calculate texture coordinates
		vertices->_n.x = -vertices->_n.x;
		vertices->_n.y = -vertices->_n.y;
		vertices->_n.z = -vertices->_n.z;
		vertices->_tex1.x = asinf(vertices->_n.x)/(2*D3DX_PI)+0.5f;
		vertices->_tex1.y = asinf(vertices->_n.z)/(2*D3DX_PI)+0.5f;
		vertices++;
	}

	m_mesh->UnlockVertexBuffer();

	D3DXCOLOR matColor = D3DXCOLOR(0.8f, 0.8f, 1.0f, 1.0f);
	m_skyMaterial.Ambient		= matColor*50.0f;
	m_skyMaterial.Diffuse		= matColor;

	return true;
}

//////////////////////////////////////////////////////////////////////////
// Render Functions
//////////////////////////////////////////////////////////////////////////

void CSkybox::Render(LPDIRECT3DDEVICE9 device, CShaderManager &shaderMgr)
{
	D3DXMATRIX world = GetWorldTransform();
	shaderMgr.SetWorldTransform(PASS_DEFAULT, world);

	device->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	device->SetRenderState(D3DRS_LIGHTING, false);
	device->SetTexture(0, m_texSkyTexture);
	shaderMgr.SetMaterial(PASS_DEFAULT, m_skyMaterial.Diffuse, m_skyMaterial.Ambient);
	m_mesh->DrawSubset(0);
	device->SetRenderState(D3DRS_LIGHTING, true);
	device->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
}

D3DXMATRIX CSkybox::GetWorldTransform() 
{
	D3DXMATRIX worldMatrix;
	D3DXMatrixIdentity(&worldMatrix);
	D3DXVECTOR3 cameraPos = m_pCamera->Get3DPosition();
	D3DXMatrixTranslation(&worldMatrix, cameraPos.x, cameraPos.y, cameraPos.z);
	return worldMatrix;
}