#pragma once
//////////////////////////////////////////////////////////////////////////
// MathUtil.h - 2011 Matthew Alford
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////
// Includes
//////////////////////////////////////

//////////////////////////////////////
// Type Definitions
//////////////////////////////////////

//////////////////////////////////////
// Constants
//////////////////////////////////////

/* Math */
const float PI			= 3.14159265358979f;

/* Collision */
enum {
	COLLIDE_OUTSIDE = 0,
	COLLIDE_INTERSECT,
	COLLIDE_CONTAINED
};

//////////////////////////////////////
// Function Declarations
//////////////////////////////////////

/* Math */
extern inline float lerp(float x, float x1, float s);
extern inline float fmax(float a, float b );
extern inline float fmin(float a, float b );
extern inline float frand(void);
extern inline float fclamp(float x, float min, float max);
extern inline bool fcompare(float a, float b);

/* Collision */
bool Collide_PointToBox(const D3DXVECTOR3 &p, const D3DXVECTOR3 &abbMin, const D3DXVECTOR3 &abbMax);
bool Collide_PointToFrustum(D3DXVECTOR3 &testPt, D3DXVECTOR3 &cameraPos, D3DXVECTOR3 cameraX, D3DXVECTOR3 cameraY, D3DXVECTOR3 cameraZ, float FOVANGLE, float ASPECT, float NEARDIST, float FARDIST, bool ignoreY = false);
int Collide_ABBToFrustum(const D3DXVECTOR3 testABBMin, const D3DXVECTOR3 testABBMax, D3DXVECTOR3 &cameraPos, D3DXVECTOR3 cameraX, D3DXVECTOR3 cameraY, D3DXVECTOR3 cameraZ, float FOVANGLE, float ASPECT, float NEARDIST, float FARDIST, bool bTest2DXZ /*= false*/);
int Collide_SphereToFrustum(D3DXVECTOR4 spherePosAndRadius, D3DXVECTOR3 cameraPos, D3DXVECTOR3 cameraX, D3DXVECTOR3 cameraY, D3DXVECTOR3 cameraZ, float FOVANGLE, float ASPECT, float NEARDIST, float FARDIST, bool bTest2DXZ);
bool Collide_SphereToBox(const D3DXVECTOR4 &s, const D3DXVECTOR3 &abbMin, const D3DXVECTOR3 &abbMax);