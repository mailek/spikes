#include "StdAfx.h"
#include "ShaderManager.h"

const float LightXRotationRateRadianSec = 1.0f;

//////////////////////////////////////////////////////////////////////////
// Setup Functions
//////////////////////////////////////////////////////////////////////////

CShaderManager::CShaderManager(void) : m_iViewportWidth(0),
										m_iViewportHeight(0),
										m_device(NULL),
										m_bDebugRotateLight(false)
{
}

CShaderManager::~CShaderManager(void)
{
	for(std::vector<ShaderPass>::iterator it = m_vecPasses.begin(), _it = m_vecPasses.end(); it != _it; it++)
	{
		COM_SAFERELEASE(it->pPS);
		COM_SAFERELEASE(it->pVS);
		COM_SAFERELEASE(it->pPSConstTable);
		COM_SAFERELEASE(it->pVSConstTable);
	}
}

void CShaderManager::SetDevice(LPDIRECT3DDEVICE9 device) 
{
	m_device = device;
	Setup();
}

void CShaderManager::Setup()
{
	////// FLAT SHADE PASS
	ShaderPass flatShadePass;
	::ZeroMemory(&flatShadePass, sizeof(flatShadePass));
	CreateVertexShader(flatShadePass, "Shaders//FlatShadeVS.fx");
	CreatePixelShader(flatShadePass, "Shaders//FlatShadePS.fx");
	m_vecPasses.push_back(flatShadePass);

	////// PLAIN RT PASS
	ShaderPass plainRTPass;
	::ZeroMemory(&plainRTPass, sizeof(plainRTPass));
	CreateVertexShader(plainRTPass, "Shaders//PlainRTVS.fx");
	CreatePixelShader(plainRTPass, "Shaders//BlurRTPS.fx");
	m_vecPasses.push_back(plainRTPass);

	////// RENDERTARGET BLUR HORZ PASS
	ShaderPass hblurRTPass;
	::ZeroMemory(&hblurRTPass, sizeof(hblurRTPass));
	hblurRTPass.pVS = m_vecPasses[PASS_RTPLAIN].pVS;
	hblurRTPass.pVS->AddRef();
	hblurRTPass.pVSConstTable = m_vecPasses[PASS_RTPLAIN].pVSConstTable;
	hblurRTPass.pVSConstTable->AddRef();
	CreatePixelShader(hblurRTPass, "Shaders//HorizontalGaussPS.fx");
	m_vecPasses.push_back(hblurRTPass);

	////// RENDERTARGET BLUR VERT PASS
	ShaderPass vblurRTPass;
	::ZeroMemory(&vblurRTPass, sizeof(vblurRTPass));
	vblurRTPass.pVS = m_vecPasses[PASS_RTPLAIN].pVS;
	vblurRTPass.pVS->AddRef();
	vblurRTPass.pVSConstTable = m_vecPasses[PASS_RTPLAIN].pVSConstTable;
	vblurRTPass.pVSConstTable->AddRef();
	CreatePixelShader(vblurRTPass, "Shaders//VerticalGaussPS.fx");
	m_vecPasses.push_back(vblurRTPass);

	////// PRIMITIVE SHADE PASS
	ShaderPass primShadePass;
	::ZeroMemory(&primShadePass, sizeof(primShadePass));
	CreateVertexShader(primShadePass, "Shaders//PrimitiveVS.fx");
	CreatePixelShader(primShadePass, "Shaders//PrimitivePS.fx");
	m_vecPasses.push_back(primShadePass);

	// DIRECTIONAL LIGHTS
	//D3DXCOLOR lightColor = D3DXCOLOR(0.5f, 0.5f, 0.5f, 1.0f);
	D3DXCOLOR lightColor = D3DXCOLOR(1.f, 1.0f, 1.0f, 1.0f);
	::ZeroMemory(&m_DirectionalLight, sizeof(m_DirectionalLight));
	m_DirectionalLight.Type		= D3DLIGHT_DIRECTIONAL;
	m_DirectionalLight.Ambient	= lightColor * 0.5f;
	m_DirectionalLight.Diffuse	= lightColor;
	m_DirectionalLight.Specular   = lightColor * 0.3f;
	m_DirectionalLight.Direction  = D3DXVECTOR3(0.0f, -1.0f, 0.0f);//D3DXVECTOR3(-0.7f, -1.0f, -0.7f);
}	
	
void CShaderManager::CreatePixelShader(ShaderPass &pass, LPCSTR psFileName)
{
	ID3DXBuffer* shader(NULL);
	ID3DXBuffer* errors(NULL);

	HRESULT hr = D3DXCompileShaderFromFile(psFileName, 0, 0, 
		"ps_main", "ps_2_0", D3DXSHADER_DEBUG, 
		&shader, &errors, &pass.pPSConstTable);

	if(errors || FAILED(hr))
	{
		std::string errorsString((char*)errors->GetBufferPointer());
		::MessageBox(0, errorsString.c_str(), "D3DXCompileShader Failed!", 0);
	}
	
	hr = m_device->CreatePixelShader((DWORD*)shader->GetBufferPointer(), &pass.pPS);
	if(FAILED(hr))
		::MessageBox(0, "Create Pixel Shader Failed!", "Create Shader Failed", 0);

	pass.pPSConstTable->SetDefaults(m_device);

	COM_SAFERELEASE(shader);
	COM_SAFERELEASE(errors);
}

void CShaderManager::CreateVertexShader(ShaderPass &pass, LPCSTR vsFileName)
{
	ID3DXBuffer* shader(NULL);
	ID3DXBuffer* errors(NULL);

	HRESULT hr = D3DXCompileShaderFromFile(vsFileName, 0, 0, 
		"vs_main", "vs_2_0", D3DXSHADER_DEBUG, 
		&shader, &errors, &pass.pVSConstTable);

	if(errors || FAILED(hr))
	{
		std::string errorsString((char*)errors->GetBufferPointer());
		::MessageBox(0, errorsString.c_str(), "D3DXCompileShader Failed!", 0);
	}
	
	hr = m_device->CreateVertexShader((DWORD*)shader->GetBufferPointer(), &pass.pVS);
	if(FAILED(hr))
		::MessageBox(0, "Create Vertex Shader Failed!", "Create Shader Failed", 0);

	pass.pVSConstTable->SetDefaults(m_device);

	COM_SAFERELEASE(shader);
	COM_SAFERELEASE(errors);
}

//////////////////////////////////////////////////////////////////////////
// Update Functions
//////////////////////////////////////////////////////////////////////////

void CShaderManager::Update(float elapsed)
{
	if(m_bDebugRotateLight)
	{
		float rotationAmount = elapsed * LightXRotationRateRadianSec;
		D3DXVECTOR3 direction = m_DirectionalLight.Direction, outDir;
		D3DXMATRIX rotMatrix;
		D3DXMatrixRotationX(&rotMatrix, rotationAmount);
		D3DXVec3TransformNormal(&outDir, &direction, &rotMatrix);
		m_DirectionalLight.Direction = outDir;
	}
}

void CShaderManager::SetVertexShader(ePassID vtShaderId)
{
	m_device->SetVertexShader(GetVertexShaderByPass(vtShaderId));
	ReloadVertexShader(vtShaderId);
}

void CShaderManager::SetPixelShader(ePassID pxShaderId)
{
	m_device->SetPixelShader(GetPixelShaderByPass(pxShaderId));
	ReloadPixelShader(pxShaderId);
}

void CShaderManager::ReloadPixelShader(ePassID passId)
{
	switch(passId)
	{
	case PASS_DEFAULT:
		break;
	case PASS_RTPLAIN:
		m_device->SetRenderState(D3DRS_FOGENABLE, FALSE);
		break;
	case PASS_RTBLURH:
		SetInvViewport(PASS_RTBLURH, (float)m_iViewportWidth, (float)m_iViewportHeight, true);
		break;
	case PASS_RTBLURV:
		SetInvViewport(PASS_RTBLURV, (float)m_iViewportWidth, (float)m_iViewportHeight, true);
		break;
	case PASS_PRIMITIVE:
		break;
	default:
		assert(false);
		break;
	}
}

void CShaderManager::ReloadVertexShader(ePassID passId)
{
	switch(passId)
	{
	case PASS_DEFAULT:
		{
		// Flat Shade
		m_vecPasses[PASS_DEFAULT].pVSConstTable->SetDefaults(m_device);

		D3DXVECTOR3 toLight = D3DXVECTOR3(0,0,0) - m_DirectionalLight.Direction;
		D3DXVECTOR3 normToLight;
		D3DXVec3Normalize(&normToLight, &toLight);
		m_vecPasses[PASS_DEFAULT].pVSConstTable->GetConstantByName(0, "toLightSource");
		
		D3DXHANDLE hLightDirection;
		hLightDirection = m_vecPasses[PASS_DEFAULT].pVSConstTable->GetConstantByName(0/*no subitem*/,"directionToLight");
		m_vecPasses[PASS_DEFAULT].pVSConstTable->SetVector(m_device, hLightDirection, &D3DXVECTOR4(normToLight, 1.0f));

		// TODO: set the lights color and intensities in the shader

		// RENDER STATES

		// fog
		m_device->SetRenderState(D3DRS_FOGCOLOR, D3DCOLOR_XRGB(128,128,128)); // gray
		m_device->SetRenderState(D3DRS_FOGENABLE, TRUE);
		break;

		}
	case PASS_RTPLAIN:
		SetInvViewport(PASS_RTPLAIN, (float)m_iViewportWidth, (float)m_iViewportHeight);
		m_device->SetRenderState(D3DRS_FOGENABLE, FALSE);
		break;
	case PASS_RTBLURH:
		SetInvViewport(PASS_RTBLURH, (float)m_iViewportWidth, (float)m_iViewportHeight);
		m_device->SetRenderState(D3DRS_FOGENABLE, FALSE);
		break;
	case PASS_RTBLURV:
		SetInvViewport(PASS_RTBLURV, (float)m_iViewportWidth, (float)m_iViewportHeight);
		m_device->SetRenderState(D3DRS_FOGENABLE, FALSE);
		break;
	case PASS_PRIMITIVE:
		break;
	default:
		assert(false);
		break;
	}
}

void CShaderManager::SetWorldTransform(ePassID pass, D3DXMATRIX worldTransform)
{
	D3DXHANDLE hWorldTransform;
	hWorldTransform = m_vecPasses[pass].pVSConstTable->GetConstantByName(0/*no subitem*/,"matWorld");
	HRESULT hr = m_vecPasses[pass].pVSConstTable->SetMatrix(m_device, hWorldTransform, &worldTransform);
	assert(!FAILED(hr));	
}

void CShaderManager::SetViewProjection(ePassID pass, D3DXMATRIX viewTransform, D3DXMATRIX projectionTransform)
{ 
	D3DXMATRIX viewProjectionTransform = viewTransform * projectionTransform;
	D3DXHANDLE viewProjTransform;
	viewProjTransform = m_vecPasses[pass].pVSConstTable->GetConstantByName(0/*no subitem*/,"matViewProjection");
	HRESULT hr = m_vecPasses[pass].pVSConstTable->SetMatrix(m_device, viewProjTransform, &viewProjectionTransform);	
	assert(!FAILED(hr));

	D3DXHANDLE hViewTransform;
	hViewTransform = m_vecPasses[pass].pVSConstTable->GetConstantByName(0/*no subitem*/,"matView");
	if(hViewTransform)
	{
		hr = m_vecPasses[pass].pVSConstTable->SetMatrix(m_device, hViewTransform, &viewTransform);	
		assert(!FAILED(hr));
	}
}

void CShaderManager::SetMaterial(ePassID pass, D3DXCOLOR diffuse, D3DXCOLOR ambient)
{
	D3DXHANDLE hDiffuseMaterial = m_vecPasses[pass].pVSConstTable->GetConstantByName(0/*no subitem*/,"diffuseMaterial");
	HRESULT hr = m_vecPasses[pass].pVSConstTable->SetVector(m_device, hDiffuseMaterial, &D3DXVECTOR4(diffuse.r, diffuse.g, diffuse.b, diffuse.a));
	assert(!FAILED(hr));

	D3DXHANDLE hAmbientMaterial = m_vecPasses[pass].pVSConstTable->GetConstantByName(0/*no subitem*/,"ambientMaterial");
	hr = m_vecPasses[pass].pVSConstTable->SetVector(m_device, hAmbientMaterial, &D3DXVECTOR4(ambient.r, ambient.g, ambient.b, ambient.a));
	assert(!FAILED(hr));
}

void CShaderManager::SetInvViewport(ePassID pass, float invWidth, float invHeight, bool pixelShader/*=false*/)
{
	float vpInvWidth = 1.0f/(float)invWidth;
	float vpInvHeight = 1.0f/(float)invHeight;

	ID3DXConstantTable* table = pixelShader ? m_vecPasses[pass].pPSConstTable : m_vecPasses[pass].pVSConstTable;
	D3DXHANDLE hInvViewportWidth = table->GetConstantByName(0/*no subitem*/, "fInverseViewportWidth");
	
	if(hInvViewportWidth)
	{
		HRESULT hr = table->SetFloat(m_device, hInvViewportWidth, vpInvWidth);
		assert(!FAILED(hr));
	}

	D3DXHANDLE hInvViewportHeight = table->GetConstantByName(0/*no subitem*/, "fInverseViewportHeight");
	if(hInvViewportHeight)
	{
		HRESULT hr = table->SetFloat(m_device, hInvViewportHeight, vpInvHeight);
		assert(!FAILED(hr));
	}
}